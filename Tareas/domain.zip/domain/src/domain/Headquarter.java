

package domain;

import java.util.ArrayList;

/**
 *
 * @author Jeison
 */
public class Headquarter extends University{
    
    private final ArrayList<Employee> employees;
    private final ArrayList<Vehicle> vehicles;
    private int quantityEmployees;
    private ArrayList<Headquarter> headquarters;

    public Headquarter(String name, String legalDocument, String ubication) {
        super(name, legalDocument, ubication);
        employees= new ArrayList<>();
        vehicles = new ArrayList<>();
        headquarters= new  ArrayList<>();
    }
}
