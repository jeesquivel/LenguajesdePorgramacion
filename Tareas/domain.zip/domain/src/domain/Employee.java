
package domain;

/**
 *
 * @author Curso
 */
class Employee {

    private String name;
    private String lastName;
    private int idCard;
    private double salary;
    private WorkingHour workinHourEntry;
    private WorkingHour workinHourExit;

    public Employee(String name, String lastName, int idCard, double salary) {
        this.name = name;
        this.lastName = lastName;
        this.idCard = idCard;
        this.salary = salary;
    }

    public Employee() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getIdCard() {
        return idCard;
    }

    public void setIdCard(int idCard) {
        this.idCard = idCard;
    }

    public WorkingHour getWorkinHour() {
        return workinHourEntry;
    }

    public void setWorkinHour(WorkingHour workinHour) {
        this.workinHourEntry = workinHour;
    }
    
    public WorkingHour getWorkinHourExit() {
        return workinHourExit;
    }

    public void setWorkinHourExit(WorkingHour workinHourExit) {
        this.workinHourExit = workinHourExit;
    }
    
}
