/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

/**
 *
 * @author Curso
 */
public class University {
    
    private String name;
    private String legalDocument;
    private String ubication;

    public University(String name, String legalDocument, String ubication) {
        this.name = name;
        this.legalDocument = legalDocument;
        this.ubication = ubication;
    }
   
    
    
    
    
}
