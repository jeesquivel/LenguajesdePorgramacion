/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.util.Date;

/**
 *
 * @author Curso
 */
public class Vehicle {
    
    private String brand;
    private String color;
    private int maxSpeed;
    private int year;
    private double mileage;
    private int state;
    private Date dateUnavailability;
    
    public Vehicle(){
    }
            
    public Vehicle(String brand, String color, int maxSpeed, int year, double mileage) {
        this.brand = brand;
        this.color = color;
        this.maxSpeed = maxSpeed;
        this.year = year;
        this.mileage = mileage;
        this.state=0;
                
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(int maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public double getMileage() {
        return mileage;
    }

    public void setMileage(double mileage) {
        this.mileage = mileage;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public Date getDateUnavailability() {
        return dateUnavailability;
    }

    public void setDateUnavailability(Date dateUnavailability) {
        this.dateUnavailability = dateUnavailability;
    }

   
   
    
}
